import torch
import numpy as np

def mean_average_precision(query_code,
                           database_code,
                           query_labels,
                           database_labels,
                           
                           topk=None,
                           ):
    """
    Calculate mean average precision(map).

    Args:
        query_code (torch.Tensor): Query data hash code.
        database_code (torch.Tensor): Database data hash code.
        query_labels (torch.Tensor): Query data targets, one-hot
        database_labels (torch.Tensor): Database data targets, one-host
        device (torch.device): Using CPU or GPU.
        topk (int): Calculate top k data map.

    Returns:
        meanAP (float): Mean Average Precision.
    """
    num_query = query_labels.shape[0]
    mean_AP = 0.0

    for i in range(num_query):
        # Retrieve images from database
        retrieval = (query_labels[i, :] @ database_labels.t() > 0).float()

        # Calculate hamming distance
        hamming_dist = 0.5 * (database_code.shape[1] - query_code[i, :] @ database_code.t())

        # Arrange position according to hamming distance
        retrieval = retrieval[np.argsort(hamming_dist.numpy())][:topk]

        # Retrieval count
        retrieval_cnt = retrieval.sum().int().item()

        # Can not retrieve images
        if retrieval_cnt == 0:
            continue

        # Generate score for every position
        score = torch.linspace(1, retrieval_cnt, retrieval_cnt).cuda()

        # Acquire index
        index = (torch.nonzero(retrieval == 1).squeeze() + 1.0).float().cuda()

        mean_AP += (score / index).mean()

    mean_AP = mean_AP / num_query
    return mean_AP


def pr_curve(tst_binary, trn_binary, tst_label, trn_label):
    #trn_binary = trn_binary.numpy()
    trn_binary = np.asarray(trn_binary, np.int32)
    trn_label = trn_label.numpy()
    #tst_binary = tst_binary.numpy()
    tst_binary = np.asarray(tst_binary, np.int32)
    tst_label = tst_label.numpy()
    query_times = tst_binary.shape[0]
    trainset_len = trn_binary.shape[0]
    AP = np.zeros(query_times)
    Ns = np.arange(1, trainset_len + 1)

    sum_p = np.zeros(trainset_len)
    sum_r = np.zeros(trainset_len)
    
    for i in range(query_times):
        #print('Query ', i+1)
        query_label = tst_label[i]
        query_binary = tst_binary[i,:]
        query_result = np.count_nonzero(query_binary != trn_binary, axis=1)    #don't need to divide binary length
        sort_indices = np.argsort(query_result)
        print(sort_indices[:11])
        #buffer_yes= np.equal(query_label, trn_label[sort_indices]).astype(int)
        buffer_yes = ((query_label @ trn_label[sort_indices].transpose())>0).astype(float)
        P = np.cumsum(buffer_yes) / Ns       
        R = np.cumsum(buffer_yes)/np.sum(buffer_yes)#(trainset_len)*10
        sum_p = sum_p+P
        sum_r = sum_r+R
    
    return sum_p/query_times,sum_r/query_times







    """
    P-R curve.

    Args
        query_code(torch.Tensor): Query hash code.
        retrieval_code(torch.Tensor): Retrieval hash code.
        query_targets(torch.Tensor): Query targets.
        retrieval_targets(torch.Tensor): Retrieval targets.
        device (torch.device): Using CPU or GPU.

    Returns
        P(torch.Tensor): Precision.
        R(torch.Tensor): Recall.
    """
    # num_query = query_code.shape[0]
    # num_bit = query_code.shape[1]
    # P = torch.zeros(num_query, num_bit + 1).cuda()
    # R = torch.zeros(num_query, num_bit + 1).cuda()
    # for i in range(num_query):
        # gnd = (query_targets[i].unsqueeze(0).mm(retrieval_targets.t()) > 0).float().squeeze().cuda()
        # tsum = torch.sum(gnd)
        # if tsum == 0:
            # continue
        # hamm = 0.5 * (retrieval_code.shape[1] - query_code[i, :] @ retrieval_code.t()).cuda()
        # tmp = (hamm <= torch.arange(0, num_bit + 1).reshape(-1, 1).float().cuda()).float()
        # total = tmp.sum(dim=-1)
        # total = total + (total == 0).float() * 0.1
        # t = gnd * tmp
        # count = t.sum(dim=-1)
        # p = count / total
        # r = count / tsum
        # P[i] = p
        # R[i] = r
    # mask = (P > 0).float().sum(dim=0)
    # mask = mask + (mask == 0).float() * 0.1
    # P = P.sum(dim=0) / mask
    # R = R.sum(dim=0) / mask
    
    
    

    #return P, R

