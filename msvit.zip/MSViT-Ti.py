from utils.tools import *
from network import *
from models.dpsh import *
from models.dptest import *
from utils.evaluate import *
import matplotlib.pyplot as plt
import torch
import torch.optim as optim
import time
from loguru import logger
import numpy as np
import functools
import torch.nn as nn
from torch.nn import init
from torch.nn import functional as F

from triplet_loss import *
from config import opt
from triplet_loss import TripletLoss
from torch.autograd import Variable

torch.multiprocessing.set_sharing_strategy('file_system')
tri_loss = TripletLoss(opt,reduction='sum')
plt.switch_backend('agg')
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
#############
def weights_init_kaiming(m, scale=1):

    classname = m.__class__.__name__
    if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
        if classname != "MeanShift":
            print('initializing [%s] ...' % classname)
            init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            m.weight.data *= scale
            if m.bias is not None:
                m.bias.data.zero_()
    elif isinstance(m, (nn.Linear)):
        init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
        m.weight.data *= scale
        if m.bias is not None:
            m.bias.data.zero_()
    elif isinstance(m, (nn.BatchNorm2d)):
        init.constant_(m.weight.data, 1.0)
        m.weight.data *= scale
        init.constant_(m.bias.data, 0.0)
#############

def get_config():
    config = {
        "alpha": 0.1,       
        "p": 2,
        "gamma": 0.05,
        "margin" : 0.4,
        #"optimizer": {"type": optim.RMSprop, "epoch_lr_decrease": 50,"optim_params": {"lr": 1e-5, "weight_decay": 10 ** -5}},
        #"alpha": 0.05,
        "optimizer": {"type": optim.SGD, "epoch_lr_decrease": 50,"optim_params": {"lr": 0.02, "weight_decay": 10 ** -5}, "lr_type": "step"},
        # "optimizer": {"type": optim.RMSprop, "optim_params": {"lr": 1e-5, "weight_decay": 10 ** -5}, "lr_type": "step"},
        "info": "crossvit-Ti",
        "resize_size": 256,
        "crop_size": 224,
        "batch_size": 1,
        "net":crossvit_9_224,
         # [ crossvit_tiny_224,deit_small_distilled_patch16_224,Resnet18_DA1，AlexNet,  AlexNet_inattention, AlexNet_DAattnetion_simple,  AlexNet_DAattnetion, AlexNet_xuezhang_attention, eca_resnet18, eca_resnet34, eca_resnet50, eca_resnet101, eca_resnet152]
        #"dataset": "cifar10",
        #"dataset":"nuswide",
        # "dataset":"coco",
        #"dataset":"nuswide_81",
        #"dataset":"imagenet",
        "dataset": "flickr25k",
        "epoch": 150,
        "evaluate_freq": 30,
        "GPU": True,
        # "GPU":False,
        "bit_list": [64, 48, 32, 16],
         #"bit_list": [48],
         "net_list" : [ "AlexNet_FReLU", "AlexNet_xuezhang_attention"]
    }
    if config["dataset"] == "cifar10":
        config["topK"] = 54000
        config["n_class"] = 10
    elif config["dataset"] == "nuswide_21":
        config["topK"] = 5000
        config["n_class"] = 21
    elif config["dataset"] == "nuswide_81":
        config["topK"] = 5000
        config["n_class"] = 81
    elif config["dataset"] == "coco":
        config["topK"] = 5000
        config["n_class"] = 80
    elif config["dataset"] == "imagenet":
        config["topK"] = 5000
        config["n_class"] = 100
    elif config["dataset"] == "flickr25k":
        config["topK"] = -1
        config["n_class"] = 24
    config["data_path"] = "./data_set/" + config["dataset"] + "/"
    if config["dataset"][:7] == "nuswide":
        config["data_path"] = "./data_set/nus-wide-10500/nus-wide/"
    config["data"] = {
        "train_set": {"list_path": "./data/" + config["dataset"] + "/train.txt", "batch_size": config["batch_size"]},
        "database": {"list_path": "./data/" + config["dataset"] + "/database.txt", "batch_size": config["batch_size"]},
        "test": {"list_path": "./data/" + config["dataset"] + "/test.txt", "batch_size": config["batch_size"]}}
    return config


def get_pair_mask(s_labels, t_labels):
    batch_size = s_labels.shape[0]
    num_data = t_labels.shape[0]
    sim_origin = s_labels.mm(t_labels.t())
    sim = (sim_origin > 0).float()
    ideal_list = torch.sort(sim_origin, dim=1, descending=True)[0]
    ph = torch.arange(0., num_data) + 2
    ph = ph.repeat(batch_size, 1).reshape(batch_size, num_data)
    th = torch.log2(ph).cuda()
    IDCG = ((2 ** ideal_list - 1) / th).sum(axis=1)
    DCG = ((2 ** sim_origin - 1)/th).sum(axis=1)
    ma3 = torch.max(DCG)
    mi3 = torch.min(DCG)
    NDCG = torch.div(IDCG , DCG)
    weight = NDCG
    #mask = sim
    return weight

def calc_loss(x1, x2, y1, y2, config):
    s = (y1 @ y2.t() > 0).float()
    inner_product = x1 @ x2.t() * 0.5
    if config["GPU"]:
        log_trick = torch.log(1 + torch.exp(-torch.abs(inner_product))) \
                    + torch.max(inner_product, torch.FloatTensor([0.]).cuda())
    else:
        log_trick = torch.log(1 + torch.exp(-torch.abs(inner_product))) \
                    + torch.max(inner_product, torch.FloatTensor([0.]))
    loss = log_trick - s * inner_product

    weight = get_pair_mask(y1, y2)
    loss1 = (loss.sum(axis=1))/config["num_train"]
    loss2 = loss1 * weight
    loss3 = loss2.mean()
    #loss2 = config["alpha"] * (x1 - x1.sign()).pow(2).mean()
    return loss3
class TriLoss(torch.nn.Module):
    def __init__(self, config, bit):
        super(TriLoss, self).__init__()
        self.U = torch.zeros(config["num_train"], bit).float().cuda
        self.Y = torch.zeros(config["num_train"], config["n_class"]).float().cuda
       
    def forward(self, u, y, index, config): 
        u = u.clamp(min=-1, max=1)  
        # self.U[index, :] = u.data
        # self.Y[index, :] = y.float() 


        # s = (y @ self.Y.t() > 0).float()
        # inner_product = u @ self.U.t() * 0.5
        
        # likelihood_loss = (1 + (-(inner_product.abs())).exp()).log() + inner_product.clamp(min=0) - s * inner_product
        # likelihood_loss = likelihood_loss.mean()
        
        triloss = tri_loss(u, y, u, margin=config["margin"])               
        triloss = config["gamma"] * triloss.mean()  
        
        # if config["p"] == 1:
        #     quantization_loss = config["alpha"] * u.mean(dim=1).abs().mean()
        # else:
        #     quantization_loss = config["alpha"] * u.mean(dim=1).pow(2).mean()
            
        #return likelihood_loss + quantization_loss + triloss
        return triloss


def train_val(config, bit):
    train_loader, test_loader, dataset_loader, num_train, num_test = get_data(config)
    config["num_train"] = num_train
    net = config["net"](bit=bit)
    ##############
    if net.__class__.__name__ in config["net_list"]:
        weights_init_kaiming_ = functools.partial(weights_init_kaiming, scale=1)
        net.apply(weights_init_kaiming_)
    ##############
    if config["GPU"]:
        net = net.cuda()
    # if torch.cuda.device_count()>1:
    #     print("Let's use ",torch.cuda.device_count(),"GPUs!")
    #     net = nn.DataParallel(net,device_ids=[0,1,2])
    # net.to(device)


    optimizer = config["optimizer"]["type"](net.parameters(), **(config["optimizer"]["optim_params"]))
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=50, gamma=0.1)

    U = torch.zeros(num_train, bit).float()
    L = torch.zeros(num_train, config["n_class"]).float()
    if config["GPU"]:
        U = U.cuda()
        L = L.cuda()
    criterion = TriLoss(config, bit)
    Best_mAP = 0
    for epoch in range(config["epoch"]):
        lr = config["optimizer"]["optim_params"]["lr"] * (0.1 ** (epoch // config["optimizer"]["epoch_lr_decrease"]))
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr

    now_time = time.time()
    for epoch in range(config["epoch"]):


        current_time = time.strftime('%H:%M:%S', time.localtime(time.time()))

        print("%s[%2d/%2d][%s] bit:%d, dataset:%s, training...." % (
            config["info"], epoch + 1, config["epoch"], current_time, bit, config["dataset"]), end="")

        net.train()

        train_loss = 0
        for image, label, index in train_loader:
            if config["GPU"]:
                image, label = image.cuda(), label.cuda()

            optimizer.zero_grad()
            b = net(image)

            U[index, :] = b.data
            L[index, :] = label.float()

            loss1 = calc_loss(b, U, label.float(), L, config)
            loss2 = criterion(b, label.float(), index, config)
            loss = loss1 + loss2
            train_loss += loss.item()
            loss.backward()
            optimizer.step()
        scheduler.step()
        train_loss = train_loss / len(train_loader)

        print("\b\b\b\b\b\b\b loss:%.3f" % (train_loss))

        if (epoch + 1) % config["evaluate_freq"] == 0:
            train_time = time.time()
            print('train_time:',train_time-now_time)
            tst_binary, tst_label = compute_result(test_loader, net, usegpu=config["GPU"])

            # trn_binary, trn_label = compute_result(train_loader, net, usegpu=config["GPU"])
            trn_binary, trn_label = compute_result(dataset_loader, net, usegpu=config["GPU"])
#t-sne 画图保存哈希码和标签
            np.savetxt('dataset_binary.txt',trn_binary,fmt= '%d')
            np.savetxt('dataset_label.txt',trn_label,fmt= '%d')
            mAP = CalcTopMap(trn_binary.numpy(), tst_binary.numpy(), trn_label.numpy(), tst_label.numpy(),
                             config["topK"]) 
            map_time = time.time()
            print('map_time:',map_time-train_time)
            print(
                "%s epoch:%d, bit:%d, dataset:%s, MAP:%.4f" % (config["info"], epoch + 1, bit, config["dataset"], mAP))
            if mAP > Best_mAP:
                Best_mAP = mAP
    print("bit:%d,Best MAP:%.4f" % (bit, Best_mAP))
    logger.info(str(bit)+'_map: {:.4f}'.format(mAP)+'_bestmap: {:.4f}'.format(Best_mAP))
    if bit == 64:
        if not os.path.isdir('result/'+config["dataset"]+'/'+config["info"]+'/'+str(bit)):
                os.makedirs('result//'+config["dataset"]+'//'+config["info"]+'//'+str(bit))
        tst_binary, tst_label = compute_result(test_loader, net, usegpu=config["GPU"])
        trn_binary, trn_label = compute_result(dataset_loader, net, usegpu=config["GPU"])
        P, R = pr_curve(
                    tst_binary,
                    trn_binary,
                    tst_label,
                    trn_label,
                )
        
        np.savetxt ('result/'+config["dataset"]+'/'+config["info"]+'/'+str(bit)+'/'+'p.txt',P,fmt='%3.5f')  
        np.savetxt ('result/'+config["dataset"]+'/'+config["info"]+'/'+str(bit)+'/'+'r.txt',R,fmt='%3.5f')
if __name__ == "__main__":
    import os
    os.environ['CUDA_VISIBLE_DEVICES'] = '1'
    # device = torch.device("cuda"if torch.cuda.is_available() else "cpu")
    config = get_config()
    logger.add('logs/mircrossvit_9_Wloss_%s_{time}.log' %str(config["net"])[20:-2])
    print(config)
    for bit in config["bit_list"]:
        train_val(config, bit)
