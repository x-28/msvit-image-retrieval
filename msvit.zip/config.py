#import warnings
import torch
class Default(object):
    
    device = 'cuda:0'
    
opt = Default()
